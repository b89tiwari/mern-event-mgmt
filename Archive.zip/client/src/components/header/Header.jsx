import "./header.css";
export default function Header() {
    return (
        <>
            <div className="header">
                <img
                    className="headerImage"
                    src="https://ventsmagazine.com/wp-content/uploads/2020/11/blog.jpg"
                    alt="blog"
                />
            </div>
        </>
    )
}